#if ((${PACKAGE_QUALIFIER} && ${PACKAGE_QUALIFIER} != ""))package ${PACKAGE_QUALIFIER} #end

package object ${PACKAGE_SIMPLE_NAME} {

}
